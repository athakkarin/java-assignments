package com.controller;
public class PaytmConstants {
  public final static String MID="wWVcFM74735574556459";
  public final static String MERCHANT_KEY="Y@8dAStqSp!xeyGu";
  public final static String INDUSTRY_TYPE_ID="Retail";
  public final static String CHANNEL_ID="WEB";
  public final static String WEBSITE="WEBSTAGING";
  public final static String PAYTM_URL="https://securegw-stage.paytm.in/theia/processTransaction"; 
  
}