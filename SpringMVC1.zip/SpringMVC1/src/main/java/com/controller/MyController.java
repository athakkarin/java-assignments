package com.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.bean.Student;
import com.dao.StudentDao;

@Controller
public class MyController {

	@RequestMapping(value="/",method = RequestMethod.GET)
	public String index()
	{
		return "insert";
	}
	@RequestMapping(value="hello",method = RequestMethod.GET)
	public String hello()
	{
		return "hello";
	}
	@RequestMapping(value="welcome",method = RequestMethod.GET)
	public String w()
	{
		return "welcome";
	}
	@RequestMapping(value="insert",method = RequestMethod.POST)
	public String insert(HttpServletRequest request,HttpServletResponse response)
	{
		ApplicationContext a=new ClassPathXmlApplicationContext("Beans.xml");
		StudentDao studentDao=a.getBean("studentDao",StudentDao.class);
		Student s=new Student();
		s.setFname(request.getParameter("fname"));
		s.setLname(request.getParameter("lname"));
		s.setEmail(request.getParameter("email"));
		studentDao.insertStudent(s);
		return "insert";
	}
}
